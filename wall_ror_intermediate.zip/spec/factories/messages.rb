FactoryGirl.define do
  factory :message do
    message "MyString"
    user_id "MyString"
  end
end
